
function hook_java() {
    Java.perform(function () {
        console.log("Starting hook...");

        let XhsHttpInterceptor = Java.use("com.xingin.shield.http.XhsHttpInterceptor");
        // XhsHttpInterceptor["intercept"].overload('okhttp3.Interceptor$Chain', 'long').implementation = function (chain, j10) {
        //     console.log(`XhsHttpInterceptor.intercept is called: chain=${chain}, j10=${j10}`);
        //
        //     console.log("============================com.xingin.shield.http.XhsHttpInterceptor======================================");
        //     var request = chain.request();
        //     var url = request.url().toString();
        //     console.log('url:',url);
        //     var headerString = request.headers().toString();
        //     console.log('headers:',headerString);
        //     console.log("============================com.xingin.shield.http.XhsHttpInterceptor end end end======================================");
        //
        //
        //
        //     let result = this["intercept"](chain, j10);
        //     console.log(`XhsHttpInterceptor.intercept result=${result}`);
        //     return result;
        // };



        // hook Request$Builder.addHeader
        try {
            var Builder = Java.use('okhttp3.Request$Builder');
            Builder.addHeader.overload('java.lang.String', 'java.lang.String').implementation = function (key, value) {
                //console.log("[addHeader] " + key + ": " + value);
                return this.addHeader(key, value);
            };
            Builder.header.overload('java.lang.String', 'java.lang.String').implementation = function (key, value) {

                if (key.indexOf("shield") >= 0){
                    console.log("[header] " + key + ": " + value);
                    console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));
                }
                return this.header(key, value);
            };
        } catch (e) {
            console.log("Request$Builder hook failed: " + e);
        }

        // hook Interceptor.intercept
//         try {
//             var Interceptor = Java.use('okhttp3.Interceptor');
//             Interceptor.intercept.implementation = function (chain) {
//                 var request = chain.request();
//                 var headers = request.headers();
//                 console.log("[Interceptor] URL: " + request.url().toString());
//                 console.log("[Interceptor] Method: " + request.method());
//                 console.log("[Interceptor] Headers:\n" + headers.toString());
//                 return this.intercept(chain);
//             };
//         } catch (e) {
//             console.log("Interceptor hook failed: " + e);
//         }
        function getArtMethod(object) {
            var artmethod = null;
            try {
                artmethod = object.$handle;
            } catch (e) {
            }
            if (artmethod == null) {
                try {
                    artmethod = object.$h;
                } catch (e) {

                }
            }
            if (artmethod == null) {
                try {
                    artmethod = object.handle;
                } catch (e) {

                }
            }
            return artmethod;
        }
        // var XhsHttpInterceptor = Java.use("com.xingin.shield.http.XhsHttpInterceptor")
        var addr_ = ptr(getArtMethod(XhsHttpInterceptor.intercept.overload('okhttp3.Interceptor$Chain', 'long'))).add(16).readPointer();
        console.log("address : ",addr_ , " module : ", JSON.stringify(Process.findModuleByAddress(addr_)))



    });
}

function hook_java2(){
    Java.perform(function () {
        var ContextHolder = Java.use('com.xingin.shield.http.ContextHolder');
        console.log('sAppId=',ContextHolder.sAppId.value);
        console.log('sDeviceId=',ContextHolder.sDeviceId.value);
        //console.log('sExperiment=',ContextHolder.sExperiment.value);
    })

}

function hook_java3(){
    // Java.perform(function () {
    //     let Base64Helper = Java.use("com.xingin.shield.http.Base64Helper");
    //     Base64Helper["decode"].implementation = function (str) {
    //         console.log(`Base64Helper.decode is called: str=${str}`);
    //         let result = this["decode"](str);
    //         console.log(`Base64Helper.decode result=${result}`);
    //         return result;
    //     };
    // })
    Java.perform(function () {
        let Base64Helper = Java.use("com.xingin.shield.http.Base64Helper");

        // 调用 decode 函数
        let input = "SGVsbG8gd29ybGQ=";  // "Hello world" 的 base64
        let result = Base64Helper.decode(input);
        console.log("主动调用 Base64Helper.decode 结果：", result);
    });

}


function hook_native(){
    var dlsym_ptr = Module.findExportByName(null, "dlsym");

    Interceptor.attach(dlsym_ptr, {
        onEnter: function (args) {
            this.handle = args[0];
            this.symbol = Memory.readUtf8String(args[1]);
        },
        onLeave: function (retval) {
            if (this.symbol) {
                var mod = Process.findModuleByAddress(retval);
                console.log("[dlsym] Symbol:", this.symbol, "=> Address:", retval,
                    mod ? "Module: " + mod.name : "(module unknown)");
            }
        }
    });

    function readStdString(ptr) {
        try {
            return Memory.readUtf8String(ptr);
        } catch (e) {
            return "(invalid)";
        }
    }

    var addr_RegisterNatives = Module.findExportByName(null, "RegisterNatives");

    Interceptor.attach(addr_RegisterNatives, {
        onEnter: function (args) {
            var env = args[0];
            var clazz = args[1];
            var methods = args[2];
            var count = args[3].toInt32();

            console.log("[RegisterNatives] count:", count);

            for (var i = 0; i < count; i++) {
                var base = methods.add(i * Process.pointerSize * 3); // struct size
                var namePtr = Memory.readPointer(base);
                var sigPtr = Memory.readPointer(base.add(Process.pointerSize));
                var fnPtr = Memory.readPointer(base.add(Process.pointerSize * 2));

                var methodName = readStdString(namePtr);
                var methodSig = readStdString(sigPtr);
                var mod = Process.findModuleByAddress(fnPtr);

                console.log("  -> Java Method:", methodName, methodSig,
                            "\n     Native Addr:", fnPtr,
                            mod ? "\n     From so: " + mod.name : "\n     From unknown module");
            }
        }
    });


}




