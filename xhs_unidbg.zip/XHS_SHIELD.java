package com.xingin;

import com.github.unidbg.AndroidEmulator;
import com.github.unidbg.Module;
import com.github.unidbg.linux.android.AndroidEmulatorBuilder;
import com.github.unidbg.linux.android.AndroidResolver;
import com.github.unidbg.linux.android.dvm.*;
import com.github.unidbg.linux.android.dvm.array.ByteArray;
import com.github.unidbg.memory.Memory;
import okhttp3.Request;
import okhttp3.Headers;
import okhttp3.RequestBody;
import okio.Buffer;
import okio.BufferedSink;
import java.io.File;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Random;


public class XHS_SHIELD extends AbstractJni {
    private final AndroidEmulator emulator;
    private final VM vm;
    private final Module module;

    XHS_SHIELD(){

        emulator = AndroidEmulatorBuilder.for64Bit().setProcessName("com.xingin.xhs").build();
        final Memory memory = emulator.getMemory();
        memory.setLibraryResolver(new AndroidResolver(23));

        vm = emulator.createDalvikVM(new File("E:\\unidbg-0.9.7\\unidbg\\unidbg-android\\src\\test\\resources\\xhs_pack\\xhs.apk"));
        DalvikModule dm = vm.loadLibrary(new File("E:\\unidbg-0.9.7\\unidbg\\unidbg-android\\src\\test\\resources\\xhs_pack\\libxyass.so"), true);

        module = dm.getModule();
        vm.setJni(this);
        //设置是否打印Jni调用细节
        vm.setVerbose(false);

        dm.callJNI_OnLoad(emulator);

    }

    public DvmObject<?> getStaticObjectField(BaseVM vm, DvmClass dvmClass, String signature) {
        switch(signature){
            case "com/xingin/shield/http/ContextHolder->sLogger:Lcom/xingin/shield/http/ShieldLogger;":
                return vm.resolveClass("com/xingin/shield/http/ShieldLogger").newObject(null);
            case "com/xingin/shield/http/ContextHolder->sDeviceId:Ljava/lang/String;":
                return new StringObject(vm,"6d0b541c-0e15-3aee-8c44-392ce5d41e5c");

        }
        return super.getStaticObjectField(vm, dvmClass, signature);
    }

    public int getStaticIntField(BaseVM vm, DvmClass dvmClass, String signature){
        switch (signature){
            case "com/xingin/shield/http/ContextHolder->sAppId:I":
                return -319115519;
        }
        return super.getStaticIntField(vm,dvmClass,signature);
    }

    public DvmObject<?> newObjectV(BaseVM vm, DvmClass dvmClass, String signature, VaList vaList) {
        switch (signature){
            case "okio/Buffer-><init>()V":
                return dvmClass.newObject(new Buffer());
        }
        return super.newObjectV(vm,dvmClass,signature,vaList);
    }

    public void callVoidMethodV(BaseVM vm, DvmObject<?> dvmObject, String signature, VaList vaList) throws IOException {
        switch (signature) {
            case "com/xingin/shield/http/ShieldLogger->nativeInitializeStart()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->nativeInitializeEnd()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->initializeStart()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->initializedEnd()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->buildSourceStart()V":
                return;
            case "okhttp3/RequestBody->writeTo(Lokio/BufferedSink;)V":
                BufferedSink bufferedSink = (BufferedSink) vaList.getObjectArg(0).getValue();
                RequestBody requestBody = (RequestBody) dvmObject.getValue();
                if (requestBody != null) {
                    try {
                            requestBody.writeTo(bufferedSink);
                    } catch (IOException e) {
                            System.out.println("错误了" + e);
                    }
                }
                return;
            case "com/xingin/shield/http/ShieldLogger->buildSourceEnd()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->calculateStart()V":
                return;
            case "com/xingin/shield/http/ShieldLogger->calculateEnd()V":
                return;
        }
        super.callVoidMethodV(vm, dvmObject, signature, vaList);
    }

    public int callIntMethodV(BaseVM vm, DvmObject<?> dvmObject, String signature, VaList vaList) {
        switch (signature) {
            case "okhttp3/Headers->size()I":
                Headers HeaderObject = (Headers) dvmObject.getValue();
                int res = HeaderObject.size();
                return res;
            case "okio/Buffer->read([B)I":
                Buffer BufferObject = (Buffer) dvmObject.getValue();
                byte[] readArg0 = (byte[])vaList.getObjectArg(0).getValue();
                return BufferObject.read(readArg0);
            case "okhttp3/Response->code()I":
                return 200;
        }
        return super.callIntMethodV(vm, dvmObject, signature, vaList);
    }
    public DvmObject<?> callObjectMethodV(BaseVM vm, DvmObject<?> dvmObject, String signature, VaList vaList) {
        switch (signature){
            case "android/content/Context->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;":

                String fileName = vaList.getObjectArg(0).getValue().toString();
                int mode = vaList.getIntArg(1);
                System.out.println("getSharedPreferences called: " + fileName + ", mode=" + mode);

                // 返回一个模拟 SharedPreferences 对象
                return vm.resolveClass("android/content/SharedPreferences").newObject(null);

            case "android/content/SharedPreferences->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;":
                String key = vaList.getObjectArg(0).getValue().toString();
                String defValue = vaList.getObjectArg(1).getValue().toString();

                System.out.println("SharedPreferences.getString key: " + key + ", default: " + defValue);

                // 模拟返回值（你可以根据 key 返回不同值）

                if (key.equals("main")) {
                    return new StringObject(vm,defValue);
                } else if ("main_hmac".equals(key)) {
                    return new StringObject(vm,"hxKAlTa/S18WetggVyxtcTmL9+PO6tK1qiG+F+P40sg1zILd9CJ6eXvT9HrmHd0sL7IJabbAdnvC0Tmhr5uqqcu1X2BEj0X3HPiH3kzCfvSi8ucg3Z0FEYgg5Bp4uvfq");
                }

            case "okhttp3/Interceptor$Chain->request()Lokhttp3/Request;":
                return vm.resolveClass("okhttp3/Request").newObject(request);

            case "okhttp3/Request->url()Lokhttp3/HttpUrl;":
                return vm.resolveClass("okhttp3/HttpUrl").newObject(request.url());

            case "okhttp3/HttpUrl->encodedPath()Ljava/lang/String;":
                return new StringObject(vm,request.url().encodedPath());

            case "okhttp3/HttpUrl->encodedQuery()Ljava/lang/String;":
                if( request.url().encodedQuery() != null) {
                    return new StringObject(vm, request.url().encodedQuery());
                }
                else return null;

            case "okhttp3/Request->body()Lokhttp3/RequestBody;":

                return  vm.resolveClass("okhttp3/RequestBody").newObject(request.body());

            case "okhttp3/Request->headers()Lokhttp3/Headers;":
                return  vm.resolveClass("okhttp3/Headers").newObject(request.headers());

            case "okio/Buffer->writeString(Ljava/lang/String;Ljava/nio/charset/Charset;)Lokio/Buffer;":
                Buffer BufferObject = (Buffer) dvmObject.getValue();
                String writeString_arg0 = vaList.getObjectArg(0).getValue().toString();
                Charset writeString_arg1 = (Charset) vaList.getObjectArg(1).getValue();
                Object res = BufferObject.writeString(writeString_arg0,writeString_arg1);
                return  vm.resolveClass("okio/Buffer").newObject(res);
            case "okhttp3/Headers->name(I)Ljava/lang/String;":
                Headers HeadersObject= (Headers) dvmObject.getValue();
                int name_arg0 = vaList.getIntArg(0);
                return new StringObject(vm,HeadersObject.name(name_arg0));
            case "okio/Buffer->clone()Lokio/Buffer;":
                Buffer Buffer_Object = (Buffer) dvmObject.getValue();
                Buffer_Object.clone();
                return dvmObject;
            case "okhttp3/Request->newBuilder()Lokhttp3/Request$Builder;":
                Request requestobj = (Request) dvmObject.getValue();
                return vm.resolveClass("okhttp3/Request$Builder").newObject(requestobj.newBuilder());
            case "okhttp3/Request$Builder->header(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;":
                Request.Builder builderObj_header = (Request.Builder) dvmObject.getValue();
                String header_arg0 = vaList.getObjectArg(0).getValue().toString();
                String header_arg1 = (String)vaList.getObjectArg(1).getValue();


                if ("shield".equals(header_arg0)) {
                    System.out.println("==========================================");
                    System.out.println("shield:XYAAQAAgAAAAEAAABTAAAAUzUWEe0xG1IbD9/c+qCLOlKGmTtFa+lG434Je+FUTaREkYTim7JmH534quFaz8N7iZh+2fE2FAxNGGfbMb6g2Co1g7deoHMiLlu+q6RU/jUuZCwV");
                    System.out.println("shield:"+header_arg1);
                    System.out.println("==========================================");
                }

                builderObj_header.header(header_arg0,header_arg1);
                return dvmObject;
            case "okhttp3/Request$Builder->build()Lokhttp3/Request;":
                Request.Builder builderObj_build= (Request.Builder) dvmObject.getValue();
                Request requestObj_build = builderObj_build.build();
                //add
                request = requestObj_build;
                //add
                return vm.resolveClass("okhttp3/Request").newObject(requestObj_build);
            case "okhttp3/Interceptor$Chain->proceed(Lokhttp3/Request;)Lokhttp3/Response;":
                return vm.resolveClass("okhttp3/Response").newObject(null);

            case "okhttp3/Headers->value(I)Ljava/lang/String;":
                Headers obj = (Headers) dvmObject.getValue();
                return new StringObject(vm,obj.value(vaList.getIntArg(0)));
        }

        return super.callObjectMethodV(vm,dvmObject,signature,vaList);
    }

    public DvmObject<?> callStaticObjectMethodV(BaseVM vm, DvmClass dvmClass, String signature, VaList vaList) {
        switch (signature) {
            case "java/nio/charset/Charset->defaultCharset()Ljava/nio/charset/Charset;":
                return dvmClass.newObject(Charset.defaultCharset());
            case "com/xingin/shield/http/Base64Helper->decode(Ljava/lang/String;)[B":
                String input = vaList.getObjectArg(0).getValue().toString();
                byte[] decodedBytes = Base64.getDecoder().decode(input);
                return new ByteArray(vm,decodedBytes);


        }
        return  super.callStaticObjectMethodV(vm,dvmClass,signature,vaList);
    }




    public void callInitializeNative(){
        DvmClass cls = vm.resolveClass("com/xingin/shield/http/XhsHttpInterceptor");
        cls.callStaticJniMethod(emulator,"initializeNative()V");
    }

    public long callInitialize(String str){
        DvmClass cls = vm.resolveClass("com/xingin/shield/http/XhsHttpInterceptor");
        //必须要用static接口，并且传入的参数需要使用unidbg的接口来包装数组
        long res = cls.callStaticJniMethodLong(emulator,"initialize(Ljava/lang/String;)J",str);
        return res;
    }


    //要模拟的函数
    public void intercept(long arg1){
        DvmClass cls = vm.resolveClass("com/xingin/shield/http/XhsHttpInterceptor");
        Object res = cls.callStaticJniMethodObject(emulator,"intercept(Lokhttp3/Interceptor$Chain;J)Lokhttp3/Response;",vm.resolveClass("okhttp3/Interceptor$Chain").newObject(null),arg1);

    }

    public static String url;
    public static Request request;




    public static void main(String[] args){

        url = "https://edith.xiaohongshu.com/api/sns/v4/user/login/password";
        request = new Request.Builder()
                .url(url)
                .addHeader("Xy-Common-Params","fid=17459111691066e1ec16e7efe974ff665fd3b4f48bef&gid=7c05bad03a305432a228243bc83d2519948bcec94735956477f12721&device_model=phone&tz=Asia%2FShanghai&channel=Vivo&versionName=8.77.0&deviceId=6d0b541c-0e15-3aee-8c44-392ce5d41e5c&platform=android&sid=session.1745911170525134532507&identifier_flag=4&project_id=ECFAAF&x_trace_page_current=login_full_screen_pwd_page&lang=zh-Hans&app_id=ECFAAF01&uis=light&teenager=0&active_ctry=CN&cpu_name=Qualcomm+Technologies%2C+Inc+SM8250&dlang=zh&launch_id=1746535514&overseas_channel=0&mlanguage=zh_cn&folder_type=none&auto_trans=0&t=1746536272&build=8770299&holder_ctry=CN&did=c8a017037efbc9964ecb43bf112d3e14")
                .addHeader("Xy-scene", "fs=0&point=1932")
                .addHeader("xy-direction","62")
//                .addHeader("X-B3-TraceId","81815d9f5b190a0f")
//                .addHeader("x-xray-traceid","cb52d64bacef4cd30cd56019e1d09739")
//                .addHeader("x-legacy-did","6d0b541c-0e15-3aee-8c44-392ce5d41e5c")
//                .addHeader("x-legacy-fid","17459111691066e1ec16e7efe974ff665fd3b4f48bef")
//                .addHeader("x-legacy-sid","session.1745911170525134532507")
//                .addHeader("x-mini-gid","7c05bad03a305432a228243bc83d2519948bcec94735956477f12721")
//                .addHeader("x-mini-s1","ADMAAAABtydgJ7nlDjj5h8fknZBTcR8cPi384v56l41kFJolICQp4wBSUzDc1Xh69Ajd3FDIrigUbyEGxB4=")
//                .addHeader("x-mini-sig","d7c622f24f6c3b74c757d78f638a424fa6f0840b038cb350707a56947c004afb")
//                .addHeader("x-mini-mua","eyJhIjoiRUNGQUFGMDEiLCJjIjo2NCwiayI6IjVjYTYxOGRiMmZkZTllYzVhMDViZDE4MGNjNWQ3MDljNGE4OGQ1MjMxMjU4ZWU5ZWI3YTRlODU2MzRhNGY3MTYiLCJwIjoiYSIsInMiOiI5OTQzODFlOWNiNWMxNDQ5NjIwMDRkZTNlNWFlZWJhZSIsInQiOnsiYyI6MTY5LCJkIjo0LCJmIjoxMDQ4NTc2LCJzIjo0MDk4LCJ0Ijo0ODIyNjkxMDAsInR0IjpbMV19LCJ1IjoiMDAwMDAwMDA3MjRkMTAyYjg0Y2EyOTcwYzk2ZTY1YWU0NWJiNTJlNyIsInYiOiIyLjguNSJ9.-Oot_HRknz4NqMkx6Wb2iYXZf0vdcIggKI3sJpRgsPJ85iZRhVHVYEq2kOQLpG83yTwMMfv9NgrSkeph9xsBhyAhPo9E8zvPeu3BC6CpaGp4tnMmeHkI03O0yrOLb4IJDDuC0TxvQ8Z9fSyeuetJoLUDx5fVZdYORhTOAj2pfUmZV7r8PVRn_PssrSon5pMApQ1LbcGRi_Xa0fPpgptWlIs7Yu1GnJNHSGQ5R9nDdRtZE3-GObkW2UU2ZQVSx6fWN8aJPI9xyNkpv7SdkHsycVy09CZJGnQTgH4EEqg756sxIayd_RKSMX7MRLvFHCkMeQFwbMs2JbFaM-6WJvuiwyXp7l8TeekoD5IBPl3TG6hMo45zrmfvqxTX-4vTyKa5kidxeIalZLE5_h9RKgeNTbDFOZY6J2To2KLpobIkxvEOf0Q3EJK0dVzI67lGj5fzMK9Mi1AJXmQsYHET4-yOuwsOVKh_dDpvopZC0sHzqtIa85ONTAGgOukgcwZ98mJ37VCfjKn5mLV2kUzk4INyABLxM8cgSBV9eEpC587Fm28KHotAzoFI-ohgf-k3AVudxtZV8STTd7nF1TkNfyLsBSbGdpPBH4hFkps6dWn00hc4rVcWUWlRK0xQFXEdPuoAYKD7SSKPa4PLxL0I531JezoZwKjm2KtBsP2mh3jtroRzvGw2idjUnvN1QehQNbdds0RtQE8WC_psB0yrqKVkkjXTx2H5op25Ei5sZM67g6SxkxuYKKdzEkZRt17KV2xZT0GV8mB5dykKXohxRIuJ13b0BNeX-NG8vF0NRffttUR50lS4QAEDF0dUWD7tjOYJKROFCI59emfKFBQjiZEYdwxzJ_En-8VQW1nVWx5CeX_kfoIfOOhHJM6gCq_3v8lOdB6ANgYJwU3Afuko1ZWa0y7Ylv0JCTC_fKQoIrsFY2C1lbfzROCm267PzLOvwHjf5gtdLweEg1ERPKZmr_jZlRFUYvqtgXXXkgSGtVD4C0PmQ5NEqKSB-8yzmKAwacWA_qVqigW6jIMhQKZZmxSFVTcrSJFUafUSyFoBBmCSEcmLrwVgxli7BXM7FSXhzOC_xCG3f4Bec1SNDZ_svvk2tmhYG6JiLg-3s0H6Bb58Q6UNPc0qd7orpP6vWHhXsu9Rwhm5NsCCziLf9yftZcusn8n5JJ8cvDu7TxecUmlUraRzK0y1Xd3VXsvgVBvj-NIRFOC3uWk0vd5seSobIHAeJp_fuNcX4skII_VM3qo--7GceEFR8IRWI_aE-agP0YwKo_BZxMiC1jgXo66i3GB2uA.")
//                .addHeader("User-Agent","Dalvik/2.1.0 (Linux; U; Android 13; M2012K11AC Build/TKQ1.220829.002) Resolution/1080*2400 Version/8.77.0 Build/8770299 Device/(Xiaomi;M2012K11AC) discover/8.77.0 NetType/WiFi")
//                .addHeader("Referer","https://app.xhs.cn/")
                .build();
        XHS_SHIELD shield = new XHS_SHIELD();
        shield.callInitializeNative();
        long res = shield.callInitialize("main");

        shield.intercept(res);

        String shieldstr = request.headers().get("shield");
        System.out.println("shield:"+shieldstr);

    }



}
